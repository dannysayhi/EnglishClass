﻿using System;

namespace PushSharp.Firefox
{
    public class FirefoxConfiguration
    {
        public FirefoxConfiguration ()
        {
        }
    }
}

