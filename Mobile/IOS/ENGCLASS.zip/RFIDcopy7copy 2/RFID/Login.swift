//
//  ViewController.swift
//  RFID
//
//  Created by 吳貫瑋 on 2018/6/6.
//  Copyright © 2018年 ITRI. All rights reserved.
//

import UIKit
import UserNotifications
import Firebase
import FirebaseDatabase

class Login: UIViewController {
    @IBOutlet weak var acc: UITextField!
    @IBOutlet weak var passwd: UITextField!
    @IBOutlet weak var info: UILabel!
    var username: String?
    var student_ID: String?
    var student_name: String?
    var groups = [String]()
    var message = [String]()
    //    var msg_dict = ["Message 1": "小孩生病", "Message 2": "小孩未出席"]
    var msg_dict = Dictionary<String, String>()

    override func viewDidLoad() {
        super.viewDidLoad()
        var ref: DatabaseReference!
        ref = Database.database().reference()
        ref.child("Course").observeSingleEvent(of: .value, with: { (snapshot) in
            for rest in snapshot.children.allObjects as! [DataSnapshot]{
                var value = rest.value as? NSDictionary
                var course_name = value?["Course_Name"] as? String ?? ""
                self.groups.append(course_name)
            }
        })

        ref.child("Messages").observeSingleEvent(of: .value, with: { (snapshot) in
            for rest in snapshot.children.allObjects as! [DataSnapshot]{
                var value = rest.value as? NSDictionary
                var msgname = value?["MsgName"] as? String ?? ""
                var msgcontent = value?["Msg"] as? String ?? ""
                self.message.append(msgname)
                self.msg_dict.updateValue(msgcontent, forKey: msgname)
                
            }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true);
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let homeVC = segue.destination as! ViewController
        homeVC._identity = acc.text
        homeVC._permission = segue.identifier
        homeVC._username = username
        homeVC._studentname = student_name
        homeVC.message = message
        homeVC.msg_dict = msg_dict
        homeVC.list = groups
    }
//    override func viewDidAppear(_ animated: Bool) {
//        self.performSegue(withIdentifier: "loginview", sender: self)
//    }
    
    func delayWithSeconds(_ seconds: Double, completion: @escaping () -> ()) {
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            completion()
        }
    }

    
    @IBAction func login(_ sender: UIButton) {
        if acc.text == "" {
            self.info.text = "登入失敗!"
            self.info.textColor = UIColor.red
        }
        else {
            var ref: DatabaseReference!
            ref = Database.database().reference()
            ref.child("User").child(acc.text!).observeSingleEvent(of: .value, with: { (snapshot) in
                // Get user value
                let value = snapshot.value as? NSDictionary
                let phone = value?["Phone"] as? String ?? ""
                if phone != "" {
                    let password = value?["Password"] as? String ?? ""
                    if password != "" && password == self.passwd.text! {
                        self.info.text = ""
                        let permission = value?["Permission"] as? String ?? ""
                        self.username = value?["Username"] as? String ?? ""
                        if permission == "toParent" {
                            self.student_ID = value?["ID"] as? String ?? ""
                            ref.child("Student").child(self.student_ID!).observeSingleEvent(of: .value, with: { (snapshot) in
                                let val = snapshot.value as? NSDictionary
                                self.student_name = val?["TwName"] as? String ?? ""
                                self.performSegue(withIdentifier: permission, sender: self)
//                                    print(self.student_name as? String ?? "")
                            })
                        }
                        else {
                            self.performSegue(withIdentifier: permission, sender: self)
                        }
//                            ref.child("User").child(self.acc.text!).child("Login").setValue("True")
                    }
                    else {
                        self.info.text = "登入失敗!"
                        self.info.textColor = UIColor.red
                    }
                }
                    else{
                        self.info.text = "登入失敗!"
                        self.info.textColor = UIColor.red
                    }
                    // ...
                }) { (error) in
                    print(error.localizedDescription)
                }
        }
    }
 }
